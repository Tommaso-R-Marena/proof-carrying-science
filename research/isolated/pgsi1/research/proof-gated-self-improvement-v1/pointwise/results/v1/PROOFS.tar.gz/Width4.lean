import Pointwise
set_option maxRecDepth 10000
set_option maxHeartbeats 20000000
open PCS.Research.IntegerAffine PCS.Research.Pointwise
namespace PCS.Research.PointwiseReplay
def claims : List PCS.Research.Pointwise.Claim := [
(.dominates (⟨[⟨(-1 : Int),(1 : Int),(-20 : Int)⟩,⟨(1 : Int),(-2 : Int),(-19 : Int)⟩,⟨(-1 : Int),(3 : Int),(-18 : Int)⟩,⟨(1 : Int),(-4 : Int),(-17 : Int)⟩],(0 : Int)⟩ : Net) (⟨[⟨(1 : Int),(-4 : Int),(-17 : Int)⟩,⟨(-1 : Int),(3 : Int),(-18 : Int)⟩,⟨(1 : Int),(-2 : Int),(-19 : Int)⟩,⟨(-1 : Int),(1 : Int),(-20 : Int)⟩],(0 : Int)⟩ : Net) (⟨[⟨(1 : Int),(2 : Int),(1 : Int)⟩],(0 : Int)⟩ : Net) [⟨⟨none,(some (-10 : Int))⟩,⟨(-6 : Int),(-36 : Int)⟩,⟨(-6 : Int),(-36 : Int)⟩,⟨(0 : Int),(0 : Int)⟩⟩,⟨⟨(some (-9 : Int)),(some (-5 : Int))⟩,⟨(-4 : Int),(-17 : Int)⟩,⟨(-4 : Int),(-17 : Int)⟩,⟨(0 : Int),(0 : Int)⟩⟩,⟨⟨(some (-4 : Int)),(some (-1 : Int))⟩,⟨(0 : Int),(0 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨(0 : Int),(0 : Int)⟩⟩,⟨⟨(some (0 : Int)),(some (6 : Int))⟩,⟨(0 : Int),(0 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨(2 : Int),(1 : Int)⟩⟩,⟨⟨(some (7 : Int)),(some (20 : Int))⟩,⟨(-3 : Int),(18 : Int)⟩,⟨(-3 : Int),(18 : Int)⟩,⟨(2 : Int),(1 : Int)⟩⟩,⟨⟨(some (21 : Int)),none⟩,⟨(-4 : Int),(38 : Int)⟩,⟨(-4 : Int),(38 : Int)⟩,⟨(2 : Int),(1 : Int)⟩⟩] : Claim)]
theorem checked : claims.all PCS.Research.Pointwise.check = true := by decide
theorem claims_sound : ∀ c ∈ claims, PCS.Research.Pointwise.Meaning c := batch_sound claims checked
#print axioms claims_sound
end PCS.Research.PointwiseReplay
