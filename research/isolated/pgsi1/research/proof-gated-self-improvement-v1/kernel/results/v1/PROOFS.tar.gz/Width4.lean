import CertificateClaims
set_option maxRecDepth 10000
set_option maxHeartbeats 20000000
open PCS.Research.IntegerAffine
namespace PCS.Research.Replayed
def claims : List Claim := [
(.equal (⟨[⟨(1 : Int),(-3 : Int),(-100 : Int)⟩,⟨(-2 : Int),(-2 : Int),(-97 : Int)⟩,⟨(3 : Int),(-1 : Int),(-94 : Int)⟩,⟨(-1 : Int),(0 : Int),(-91 : Int)⟩],(7 : Int)⟩ : Net) (⟨[⟨(-1 : Int),(0 : Int),(-91 : Int)⟩,⟨(3 : Int),(-1 : Int),(-94 : Int)⟩,⟨(-2 : Int),(-2 : Int),(-97 : Int)⟩,⟨(1 : Int),(-3 : Int),(-100 : Int)⟩],(7 : Int)⟩ : Net) [⟨⟨none,(some (-95 : Int))⟩,⟨(-2 : Int),(-181 : Int)⟩,⟨(-2 : Int),(-181 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-94 : Int)),(some (-49 : Int))⟩,⟨(1 : Int),(101 : Int)⟩,⟨(1 : Int),(101 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-48 : Int)),(some (-34 : Int))⟩,⟨(-3 : Int),(-93 : Int)⟩,⟨(-3 : Int),(-93 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-33 : Int)),none⟩,⟨(0 : Int),(7 : Int)⟩,⟨(0 : Int),(7 : Int)⟩,⟨0,0⟩⟩] : Claim),
(.maximum (⟨[⟨(1 : Int),(-3 : Int),(-100 : Int)⟩,⟨(-2 : Int),(-2 : Int),(-97 : Int)⟩,⟨(3 : Int),(-1 : Int),(-94 : Int)⟩,⟨(-1 : Int),(0 : Int),(-91 : Int)⟩],(7 : Int)⟩ : Net) (⟨[⟨(1 : Int),(2 : Int),(1 : Int)⟩],(0 : Int)⟩ : Net) [⟨⟨none,(some (-95 : Int))⟩,⟨(-2 : Int),(-181 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-94 : Int)),(some (-49 : Int))⟩,⟨(1 : Int),(101 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-48 : Int)),(some (-34 : Int))⟩,⟨(-3 : Int),(-93 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (-33 : Int)),(some (-1 : Int))⟩,⟨(0 : Int),(7 : Int)⟩,⟨(0 : Int),(0 : Int)⟩,⟨0,0⟩⟩,⟨⟨(some (0 : Int)),none⟩,⟨(0 : Int),(7 : Int)⟩,⟨(2 : Int),(1 : Int)⟩,⟨0,0⟩⟩] (-1000 : Int) (1000 : Int) 1994 (1000 : Int) : Claim)]
theorem checked : claims.all checkClaim = true := by decide
theorem claims_sound : ∀ c ∈ claims, Meaning c := checkBatch_sound claims checked
#print axioms claims_sound
end PCS.Research.Replayed
