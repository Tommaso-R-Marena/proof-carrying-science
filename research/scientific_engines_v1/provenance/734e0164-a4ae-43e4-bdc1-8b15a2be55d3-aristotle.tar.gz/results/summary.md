| case | core states | L | U | U/L-1 | FSP upper (L+P_exit) | P_exit | SSA hits/n | synth s | check s |
|---|---|---|---|---|---|---|---|---|---|
| A_birth_death_N10 | 10 | 9.775171e-04 | 9.775171e-04 | 4.21e-08 | 9.775e-04 | 0.00e+00 | 23/20000 | 0.064 | 0.001 |
| A_birth_death_N20 | 20 | 9.536752e-07 | 9.536753e-07 | 1.02e-07 | 9.537e-07 | 0.00e+00 | 0/20000 | 0.188 | 0.001 |
| A_birth_death_N40 | 40 | 9.094946e-13 | 9.094948e-13 | 2.22e-07 | 9.095e-13 | 0.00e+00 | 0/20000 | 0.51 | 0.002 |
| A_birth_death_N80 | 80 | 8.271804e-25 | 8.271808e-25 | 4.62e-07 | 8.272e-25 | 0.00e+00 | 0/20000 | 1.392 | 0.004 |
| B_gene_expression_N40 | 600 | 6.132154e-06 | 6.132156e-06 | 2.66e-07 | 6.132e-06 | 6.21e-21 | 1/20000 | 2.376 | 0.058 |
| B_gene_expression_N60 | 900 | 1.653822e-09 | 1.653823e-09 | 3.79e-07 | 1.654e-09 | 2.43e-20 | 0/20000 | 3.689 | 0.09 |
| B_gene_expression_N80 | 1200 | 2.318491e-13 | 2.318524e-13 | 1.40e-05 | 2.318e-13 | 2.93e-20 | 0/20000 | 5.282 | 0.12 |
| C_modulated_growth_N20 | 800 | 5.055628e-06 | 5.055629e-06 | 2.24e-07 | 5.056e-06 | 2.35e-13 | 0/20000 | 22.492 | 0.096 |
| C_modulated_growth_N30 | 1200 | 3.906988e-08 | 3.906989e-08 | 3.13e-07 | 3.907e-08 | 2.35e-13 | 0/20000 | 38.764 | 0.144 |
| C_modulated_growth_N40 | 1600 | 5.189777e-10 | 5.189779e-10 | 4.00e-07 | 5.192e-10 | 2.35e-13 | 0/20000 | 55.043 | 0.195 |
| C_modulated_growth_N60 | 2400 | 2.803341e-13 | 2.803343e-13 | 5.73e-07 | 5.151e-13 | 2.35e-13 | 0/20000 | 100.893 | 0.301 |
| C_modulated_growth_N30_smallbox | 660 | 3.906193e-08 | 3.908710e-08 | 6.44e-04 | 7.151e-04 | 7.15e-04 | - | 14.836 | 0.079 |

Robust (Example C, N=30): [{"pct": 1, "upper_ok": true, "lower_ok": true, "U": 7.575092464009098e-08, "L": 2.0082830391464397e-08, "t_s": 10.12, "vertex_growth_favouring_U": 7.575081438019202e-08, "vertex_growth_suppressing_L": 2.008285784506832e-08}, {"pct": 5, "upper_ok": true, "lower_ok": true, "U": 1.0322016910000726e-06, "L": 1.3575445348715828e-09, "t_s": 11.83, "vertex_growth_favouring_U": 1.032199965015156e-06, "vertex_growth_suppressing_L": 1.3575461885572958e-09}]

Lean verified-checker runs: {"RequestProject/AION/Examples/BDcert.lean": {"ok": true, "t_s": 8.4}, "RequestProject/AION/Examples/GeneCert.lean": {"ok": true, "t_s": 10.1}, "RequestProject/AION/Examples/XYsmall.lean": {"ok": true, "t_s": 11.2}, "RequestProject/AION/Examples/XYmain.lean": {"ok": true, "t_s": 13.2}}
