#!/usr/bin/env python3
"""One-command reproduction: tests, certificates, benchmarks, Lean export/build.

usage:  python3 scripts/run_all.py [--quick] [--lean] [--no-ssa]

Writes results/benchmarks.json, results/summary.md and certificates/*.json.
With --lean also regenerates the Lean certificate files, runs `lake build`, and times
the Lean (verified-checker) validation of each exported certificate.
"""
import argparse
import json
import os
import subprocess
import sys
import time
from fractions import Fraction as Q

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "python"))

from aion import checker as ck, models, reference, robust, synth, emit_lean  # noqa: E402


def fmt(q):
    return f"{float(q):.6e}"


def run_case(name, crn, jB, lvl, zero, box, x0, ssa_n, exact=None, lean_name=None):
    t0 = time.time()
    cert, err = synth.synth_sandwich(crn, jB, lvl, zero, box, x0)
    t_syn = time.time() - t0
    if cert is None:
        return {"name": name, "error": err}
    t0 = time.time()
    rep = ck.check_certificate(cert)
    t_chk = time.time() - t0
    L = Q(rep["lower_at_x0"]); U = Q(rep["upper_at_x0"])
    nstates = 1
    for b in box:
        nstates *= b
    fsp_L, fsp_U, p_exit = reference.fsp_bounds(crn, jB, lvl, zero, box, x0)
    row = {
        "name": name, "species": crn.species, "level": lvl, "box": box, "x0": list(x0),
        "core_states": nstates, "ok": rep["ok"],
        "L": float(L), "U": float(U), "rel_gap": float(U / L - 1) if L > 0 else None,
        "claim_L": cert["claim"]["lower"], "claim_U": cert["claim"]["upper"],
        "t_synth_s": round(t_syn, 3), "t_check_python_s": round(t_chk, 3),
        "fsp_L": fsp_L, "fsp_U": fsp_U, "fsp_exit_prob": p_exit,
        "cert_bytes": len(json.dumps(cert)),
    }
    if exact is not None:
        row["exact"] = float(exact)
        row["exact_in_sandwich"] = bool(L <= exact <= U)
    if ssa_n:
        t0 = time.time()
        s = reference.ssa_estimate(crn, jB, lvl, zero, x0, ssa_n, seed=1)
        s["t_s"] = round(time.time() - t0, 2)
        row["ssa"] = s
    os.makedirs(os.path.join(ROOT, "certificates"), exist_ok=True)
    with open(os.path.join(ROOT, "certificates", f"{name}.json"), "w") as f:
        json.dump(cert, f)
    if lean_name:
        emit_lean.emit(cert, lean_name,
                       os.path.join(ROOT, "RequestProject", "AION", "Examples", f"{lean_name}.lean"))
        row["lean_file"] = f"RequestProject/AION/Examples/{lean_name}.lean"
    print(f"[{name}] ok={rep['ok']} L={fmt(L)} U={fmt(U)} U/L-1={row['rel_gap']:.2e} "
          f"FSP-U={fsp_U:.3e} synth={t_syn:.1f}s check={t_chk:.2f}s", flush=True)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--lean", action="store_true")
    ap.add_argument("--no-ssa", action="store_true")
    args = ap.parse_args()
    ssa_n = 0 if args.no_ssa else (2000 if args.quick else 20000)

    print("== unit / adversarial tests ==", flush=True)
    r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"],
                       cwd=ROOT, env={**os.environ, "PYTHONPATH": os.path.join(ROOT, "python")})
    if r.returncode != 0:
        print("TESTS FAILED"); sys.exit(1)

    rows = []
    print("== Example A: linear birth-death (exact reference) ==", flush=True)
    for N in ([10, 20] if args.quick else [10, 20, 40, 80]):
        c = models.birth_death(Q(1), Q(2))
        ex = reference.birth_death_exact(Q(1), Q(2), N, 1)
        rows.append(run_case(f"A_birth_death_N{N}", c, 0, N, [True], [N], (1,), ssa_n, exact=ex,
                             lean_name=("BDcert" if N == 20 else None)))

    print("== Example B: bursty gene expression ==", flush=True)
    for N in ([40] if args.quick else [40, 60, 80]):
        c = models.gene_expression()
        rows.append(run_case(f"B_gene_expression_N{N}", c, 1, N, [False, True], [15, N], (0, 1), ssa_n,
                             lean_name=("GeneCert" if N == 40 else None)))

    print("== Example C: degradation-modulated growth (scalable family) ==", flush=True)
    for N in ([20, 30] if args.quick else [20, 30, 40, 60]):
        c = models.degradation_modulated_growth()
        rows.append(run_case(f"C_modulated_growth_N{N}", c, 0, N, [True, False], [N, 40], (1, 10), ssa_n,
                             lean_name=({30: "XYmain", 20: "XYsmall"}.get(N))))
    # small-box variant to show the weighted-interface effect vs unweighted FSP
    c = models.degradation_modulated_growth()
    rows.append(run_case("C_modulated_growth_N30_smallbox", c, 0, 30, [True, False], [30, 22], (1, 10), 0))

    print("== Robust parameters (Example C, N=30, box 30x40) ==", flush=True)
    rob = []
    c = models.degradation_modulated_growth()
    for pct in ([1] if args.quick else [1, 5]):
        iv = [(R.k * Q(100 - pct, 100), R.k * Q(100 + pct, 100)) for R in c.reactions]
        t0 = time.time()
        out = robust.synth_robust(c, iv, 0, 30, [True, False], [30, 40], (1, 10), [Q(2), Q(11, 10)])
        dt = time.time() - t0
        rr = {"pct": pct, "upper_ok": out["upper_ok"], "lower_ok": out["lower_ok"],
              "U": float(out["U"]) if "U" in out else None, "L": float(out["L"]) if "L" in out else None,
              "t_s": round(dt, 2)}
        # constant-parameter extreme vertex (growth-favouring) for comparison
        wc = models.degradation_modulated_growth(b=iv[0][1], d=iv[1][0], alpha=iv[2][0], beta=iv[3][1], k=iv[4][0])
        cert, _ = synth.synth_sandwich(wc, 0, 30, [True, False], [30, 40], (1, 10))
        if cert:
            rr["vertex_growth_favouring_U"] = float(Q(ck.check_certificate(cert)["upper_at_x0"]))
        bc = models.degradation_modulated_growth(b=iv[0][0], d=iv[1][1], alpha=iv[2][1], beta=iv[3][0], k=iv[4][1])
        cert, _ = synth.synth_sandwich(bc, 0, 30, [True, False], [30, 40], (1, 10))
        if cert:
            rr["vertex_growth_suppressing_L"] = float(Q(ck.check_certificate(cert)["lower_at_x0"]))
        print("  robust", rr, flush=True)
        rob.append(rr)

    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    out = {"cases": rows, "robust": rob, "python": sys.version}

    if args.lean:
        print("== Lean: build verified checker + certificates ==", flush=True)
        t0 = time.time()
        r = subprocess.run(["lake", "build"], cwd=ROOT)
        out["lean_build_ok"] = r.returncode == 0
        out["lean_build_s"] = round(time.time() - t0, 1)
        lean_t = {}
        for row in rows:
            lf = row.get("lean_file")
            if lf:
                t0 = time.time()
                r = subprocess.run(["lake", "env", "lean", lf], cwd=ROOT, capture_output=True, text=True)
                lean_t[lf] = {"ok": r.returncode == 0 and "error" not in r.stdout,
                              "t_s": round(time.time() - t0, 1)}
                print("  ", lf, lean_t[lf], flush=True)
        out["lean_certificate_checks"] = lean_t

    with open(os.path.join(ROOT, "results", "benchmarks.json"), "w") as f:
        json.dump(out, f, indent=1)
    with open(os.path.join(ROOT, "results", "summary.md"), "w") as f:
        f.write("| case | core states | L | U | U/L-1 | FSP upper (L+P_exit) | P_exit | SSA hits/n | synth s | check s |\n")
        f.write("|---|---|---|---|---|---|---|---|---|---|\n")
        for r_ in rows:
            if "error" in r_:
                f.write(f"| {r_['name']} | error: {r_['error']} |\n")
                continue
            s = r_.get("ssa")
            ss = f"{s['hits']}/{s['n']}" if s else "-"
            f.write(f"| {r_['name']} | {r_['core_states']} | {r_['L']:.6e} | {r_['U']:.6e} | {r_['rel_gap']:.2e} | "
                    f"{r_['fsp_U']:.3e} | {r_['fsp_exit_prob']:.2e} | {ss} | {r_['t_synth_s']} | {r_['t_check_python_s']} |\n")
        f.write("\nRobust (Example C, N=30): " + json.dumps(rob) + "\n")
        if "lean_certificate_checks" in out:
            f.write("\nLean verified-checker runs: " + json.dumps(out["lean_certificate_checks"]) + "\n")
    print("done; see results/summary.md")


if __name__ == "__main__":
    main()
