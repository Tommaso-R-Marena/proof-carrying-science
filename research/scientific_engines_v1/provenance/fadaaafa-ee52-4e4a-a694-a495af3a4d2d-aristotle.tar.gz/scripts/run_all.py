#!/usr/bin/env python3
"""PRISM: single reproducible entry point.

    python3 scripts/run_all.py            # full run
    python3 scripts/run_all.py --quick    # quick benchmarks, fewer Lean agreement cases
    python3 scripts/run_all.py --no-lean  # skip everything that needs `lake`

Steps (each logged to results/logs/<step>.log; the run stops at the first failure):
  1. lake build PRISM                          (formal library, incl. generated examples)
  2. source scan: no sorry/admit/axiom/native_decide/implemented_by in PRISM/
  3. axiom audit: lake env lean PRISM/AxiomAudit.lean -> results/axiom_audit.txt
  4. tests: differential, serialization, Lean/Python checker agreement
  5. examples: biochemical, noisy biochemical, causal, scalable
     (the example scripts regenerate PRISM/Examples/Generated/*.lean; step 6
      rebuilds them so the committed Lean files are re-checked by the kernel)
  6. lake build PRISM (again, after regeneration)
  7. benchmarks -> results/benchmarks.{json,csv}; report -> results/report.html
"""
import os
import re
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LOGS = os.path.join(ROOT, "results", "logs")
QUICK = "--quick" in sys.argv
NO_LEAN = "--no-lean" in sys.argv


def step(name, cmd, env=None, out_file=None):
    os.makedirs(LOGS, exist_ok=True)
    t0 = time.time()
    print(f"[run_all] {name}: {' '.join(cmd)}", flush=True)
    e = dict(os.environ)
    e.update(env or {})
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, env=e)
    log = r.stdout + ("\n--- stderr ---\n" + r.stderr if r.stderr else "")
    with open(os.path.join(LOGS, f"{name}.log"), "w") as f:
        f.write(log)
    if out_file:
        with open(os.path.join(ROOT, out_file), "w") as f:
            f.write(r.stdout)
    dt = time.time() - t0
    if r.returncode != 0:
        print(f"[run_all] FAILED {name} ({dt:.1f}s); see results/logs/{name}.log")
        print(log[-3000:])
        sys.exit(1)
    print(f"[run_all] ok {name} ({dt:.1f}s)", flush=True)
    return r.stdout


def source_scan():
    bad = re.compile(r"\b(sorry|admit|native_decide|implemented_by)\b|^\s*axiom\s", re.M)
    hits = []
    for d, _, fs in os.walk(os.path.join(ROOT, "PRISM")):
        for fn in fs:
            if fn.endswith(".lean"):
                p = os.path.join(d, fn)
                src = open(p, encoding="utf-8").read()
                # strip comments (block and line) before scanning
                src = re.sub(r"/-.*?-/", "", src, flags=re.S)
                src = re.sub(r"--.*", "", src)
                for m in bad.finditer(src):
                    hits.append(f"{os.path.relpath(p, ROOT)}: {m.group(0).strip()}")
    with open(os.path.join(LOGS, "source_scan.log"), "w") as f:
        f.write("\n".join(hits) or "clean\n")
    if hits:
        print("[run_all] FAILED source scan:\n" + "\n".join(hits))
        sys.exit(1)
    print("[run_all] ok source scan (no sorry/admit/axiom/native_decide/implemented_by)")


def main():
    py = sys.executable
    if not NO_LEAN:
        step("lake_build", ["lake", "build", "PRISM"])
    os.makedirs(LOGS, exist_ok=True)
    source_scan()
    if not NO_LEAN:
        out = step("axiom_audit", ["lake", "env", "lean", "PRISM/AxiomAudit.lean"],
                   out_file="results/axiom_audit.txt")
        allowed = {"propext", "Classical.choice", "Quot.sound"}
        for line in out.splitlines():
            m = re.search(r"depends on axioms: \[(.*)\]", line)
            if m:
                axs = {a.strip() for a in m.group(1).split(",") if a.strip()}
                if not axs <= allowed:
                    print(f"[run_all] FAILED axiom audit: {line}")
                    sys.exit(1)
            elif "sorry" in line:
                print(f"[run_all] FAILED axiom audit: {line}")
                sys.exit(1)
    step("test_differential", [py, "tests/test_differential.py"])
    step("test_serialization", [py, "tests/test_serialization.py"])
    if not NO_LEAN:
        step("test_lean_agreement", [py, "tests/test_lean_agreement.py"],
             env={"PRISM_LEAN_AGREEMENT_N": "2" if QUICK else "6"})
    step("demo_biochemical", [py, "examples/biochemical/build.py"])
    step("demo_noisy", [py, "examples/biochemical/noisy.py"])
    step("demo_causal", [py, "examples/causal/build.py"])
    step("demo_scalable", [py, "examples/scalable/run.py"])
    if not NO_LEAN:
        step("lake_build_regenerated", ["lake", "build", "PRISM"])
    step("benchmarks", [py, "python/benchmarks/run_benchmarks.py"] + (["--quick"] if QUICK else []))
    step("report", [py, "python/benchmarks/make_report.py"])
    print("[run_all] ALL STEPS PASSED")


if __name__ == "__main__":
    main()
